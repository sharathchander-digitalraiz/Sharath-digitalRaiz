module.exports={
    "facebook_api_key"      :     "",
    "facebook_api_secret"   :     "",
    "callback_url"          :     "",
    "use_database"          :      false,
    "host"                  :     "localhost",
    "username"              :     "root",
    "password"              :     "",
    "database"              :     "Database Name",
    "secret"                :     'worldisfullofdevelopers'
  }
